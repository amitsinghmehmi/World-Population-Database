import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.text.DecimalFormat;
import java.util.Arrays;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/**
 * 
 */

/**
 * @author Amit Singh Mehmi
 * Date: June 13th, 2022 
 * Description: This program is an interactive database for the world's population
 * Method List: 	public static void display(String countryName[], double countryPopulation[], double worldPopulation, double percentTotal[]) - Method to display data on a JTextArea
 *					public static double percentTotal(double countryPopulation, double worldPopulation) - Method to calculate percent total of a country
 *					public static void alphaOrder(String countryName[], double countryPopulation[], double worldPopulationVariable, double percentTotal[], String countryFlags[]) - Method to sort an array in alphabetical order
 *					public static void lowToHigh(String countryName[], double countryPopulation[], double worldPopulationVariable, double percentTotal[], String countryFlags[]) - Method to sort an array in ascending order
 *					public static void saveFiles(String countryName[], double countryPopulation[], double worldPopulationVariable, double percentTotal[]) - Method to save data into a new file
 *					public static int findCountry(String countries[], String searchKey) - Method to search for a specific country specified by the user
 */
public class WorldPopulationStudy {

	// To format number to two decimal places
	static DecimalFormat twoDigits = new DecimalFormat("#0.00");

	// To format number to no decimal place
	static DecimalFormat oneDigit = new DecimalFormat("#0");

	// Declare variable for flexible array size
	static int numOfCountries = 0;

	// Declare and initialize imageicons 
	static ImageIcon find = new ImageIcon("find.png");
	static ImageIcon save = new ImageIcon("save.png");

	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException {

		// Declare the arrays for country name, population and percentage from total
		String countryName[];
		String countryFlags[];
		double countryPopulation[];
		double worldPopulation[];
		double percentTotal[];

		// Ask user for file name to be read from
		String fileName = JOptionPane.showInputDialog(null, "Enter file name to read from: ", "FILE NAME", JOptionPane.INFORMATION_MESSAGE);

		// Declare reading functions outside of try catch
		FileReader fileR = null;
		BufferedReader input = null;

		// Declare boolean to keep asking user if wrong information is entered
		Boolean correctInfo = false;

		// Trap exception of while file name is not found
		while(correctInfo != true) {

			try {
				// Open the data file for reading population data
				fileR = new FileReader(fileName);	// Find the file
				input = new BufferedReader(fileR);
				correctInfo = true;
			}
			catch (Exception e) {
				fileName = JOptionPane.showInputDialog(null, "File Not Found! Try Again!: ", "FILE NOT FOUND!", JOptionPane.INFORMATION_MESSAGE);
			}
		}

		// Store the number of countries
		numOfCountries = Integer.parseInt(input.readLine());

		// Create the arrays with the size of the flexible number
		countryName = new String[numOfCountries];
		countryFlags = new String[numOfCountries];
		countryPopulation = new double[numOfCountries];
		percentTotal = new double[numOfCountries];
		worldPopulation = new double[1];	// Set to 1 because there is only one number at the end

		// Use a for loop to load the data into the arrays
		for (int i = 0; i < numOfCountries; i++) {
			// Load the country names and their populations
			countryName[i] = input.readLine();
			countryPopulation[i] = Double.parseDouble(input.readLine());
		}

		// Store the world population in the first index of the array
		worldPopulation[0] = Double.parseDouble(input.readLine());
		double worldPopulationVariable = worldPopulation[0];

		// Close the file
		fileR.close();

		// Open the data file for reading picture data
		FileReader fileR2 = new FileReader("CountryFlags.txt");	// Find the file
		BufferedReader input2 = new BufferedReader(fileR2);

		// Use a for loop to load the picture data into the arrays
		for (int i = 0; i < numOfCountries; i++) {
			// Load the country flags
			countryFlags[i] = input2.readLine();
		}

		fileR2.close(); // Close the file

		// Call percentTotal method to obtain %total of specific country
		for (int i = 0; i < numOfCountries; i++) {
			percentTotal[i] = percentTotal(countryPopulation[i], worldPopulationVariable);
		}

		// Call display method to display all data in a JTextArea
		WorldPopulationStudy.display(countryName, countryPopulation, worldPopulationVariable, percentTotal);

		// Ask if user wants to save new data
		int saveOption = JOptionPane.showConfirmDialog(null,"Save Unsorted Information?", "SAVE", JOptionPane.YES_NO_OPTION);

		if (saveOption == JOptionPane.YES_OPTION) {

			WorldPopulationStudy.saveFiles(countryName, countryPopulation, worldPopulationVariable, percentTotal);

		}

		// Call lowToHigh method to display ascending order 
		WorldPopulationStudy.lowToHigh(countryName, countryPopulation, worldPopulationVariable, percentTotal, countryFlags);

		saveOption = JOptionPane.showConfirmDialog(null,"Save Ascending Order?", "SAVE", JOptionPane.YES_NO_OPTION);

		if (saveOption == JOptionPane.YES_OPTION) {

			WorldPopulationStudy.saveFiles(countryName, countryPopulation, worldPopulationVariable, percentTotal);

		}

		// Call alphaOrder method to display in aplhabetical order 
		WorldPopulationStudy.alphaOrder(countryName, countryPopulation, worldPopulationVariable, percentTotal, countryFlags);

		saveOption = JOptionPane.showConfirmDialog(null,"Save Alphabetical Order?", "SAVE", JOptionPane.YES_NO_OPTION);

		if (saveOption == JOptionPane.YES_OPTION) {

			WorldPopulationStudy.saveFiles(countryName, countryPopulation, worldPopulationVariable, percentTotal);

		}

		// Prompt for a country to be searched 
		String countryToFind = (String) JOptionPane.showInputDialog(null, "Enter a country to search for: ", "SEARCH", JOptionPane.INFORMATION_MESSAGE, find, null, "");

		// Call the search method
		int location = WorldPopulationStudy.findCountry(countryName, countryToFind);

		// Check if the name was found
		if(location >= 0) {

			// Initialize countryFlag to searched country's flag 
			ImageIcon countryFlag = new ImageIcon(countryFlags[location]);

			// Display found
			JOptionPane.showMessageDialog(null,"Country: " + countryName[location] + "\n" + "Population: " + (int)countryPopulation[location] + "\nPercent Total: " + percentTotal[location] + "%", "COUNTRY FOUND!", JOptionPane.INFORMATION_MESSAGE, countryFlag);

			// Ask if user wants to refactor country information
			int changeOption = JOptionPane.showConfirmDialog(null,"Refactor Country Data?", "REFACTOR", JOptionPane.YES_NO_OPTION);

			// If user wants to change the information
			if (changeOption == JOptionPane.YES_OPTION) {

				// Set new population to same location 
				countryPopulation[location] = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter New Country Population For " + countryName[location] + ":"));

				// Call percent total method to calculate new percent total
				percentTotal[location] = percentTotal(countryPopulation[location], worldPopulationVariable);

				// Call lowToHigh method to display ascending order 
				WorldPopulationStudy.lowToHigh(countryName, countryPopulation, worldPopulationVariable, percentTotal, countryFlags);

				// Ask if user wants to save new data
				saveOption = JOptionPane.showConfirmDialog(null,"Save New Information?", "SAVE", JOptionPane.YES_NO_OPTION);

				if (saveOption == JOptionPane.YES_OPTION) {

					WorldPopulationStudy.saveFiles(countryName, countryPopulation, worldPopulationVariable, percentTotal);

				}
				else {
					// Otherwise display a friendly message
					JOptionPane.showMessageDialog(null, "Have A Nice Day!", "THANK YOU!", JOptionPane.INFORMATION_MESSAGE);
				}
			}
			else {
				// Otherwise display a friendly message
				JOptionPane.showMessageDialog(null, "Have A Nice Day!", "THANK YOU!", JOptionPane.INFORMATION_MESSAGE);
			}
		}
		else {
			// Display not found
			JOptionPane.showMessageDialog(null, "No Information Found For: " + countryToFind, "COUNTRY NOT FOUND!", JOptionPane.INFORMATION_MESSAGE);
		}

		// Write to a new file formatted with only high population percentage 
		FileWriter fileHigh = new FileWriter("HIGHPOPULATION.txt");	// Open the file to write to 
		PrintWriter outputHigh = new PrintWriter(fileHigh);	

		// Write to a new file formatted with only low population percentage 
		FileWriter fileLow = new FileWriter("LOWPOPULATION.txt");	// Open the file to write to 
		PrintWriter outputLow = new PrintWriter(fileLow);	
		
		// For loop too check each percent total of country
		for (int i = 0; i < percentTotal.length; i++) {
			
			// If percent total is greater than or equal to 2.7 write to highpopulation.txt
			if (percentTotal[i] >= 2.7) {
				outputHigh.println("Country: " + countryName[i] + " Population: " + (int)countryPopulation[i] + " % Total: " + percentTotal[i]);
			}
			// else write to lowpopulation.txt
			else {
				outputLow.println("Country: " + countryName[i] + " Population: " + (int)countryPopulation[i] + " % Total: " + percentTotal[i]);
			}
		}
		
		// Close the files
		fileHigh.close();
		fileLow.close();
	}

	/**
	 * Method to display information
	 */
	public static void display(String countryName[], double countryPopulation[], double worldPopulation, double percentTotal[]) {

		// Create a Text Output Area
		JTextArea outputArea = new JTextArea();

		// Sets JTextArea font and color.
		Font font = new Font("Serif", Font.BOLD, 16);
		outputArea.setFont(font);
		outputArea.setBackground(Color.GRAY);
		outputArea.setForeground(Color.WHITE);
		outputArea.setEditable(false);	// Disable deleting 

		// Initialize variable for tab size 
		int tabSize = 0;

		// Find the greatest length
		for (int i = 0; i < countryName.length; i++) {
			if (countryName[i].length() > tabSize) {
				tabSize = countryName[i].length();
			}
		}

		// Set the tab size to the greatest length + 1
		outputArea.setTabSize(tabSize + 1);

		// Display the whole thing in a nice dialog box 
		String list = "Country\tPopulation\t% of Total\n";
		list = list + "======\t======\t======";

		// Add the country names, populations and percent totals to the list
		for (int i = 0; i < countryName.length; i++) {
			list = list + "\n" + countryName[i] + "\t" + (int)countryPopulation[i] + "\t" + percentTotal[i] + "%";
		}

		// Add the world population at the end of the list
		list = list + "\n\nTotal World Population: \t" + oneDigit.format(worldPopulation);

		// Add the list to the JTextArea
		outputArea.setText(list);

		// Display it in a dialog box
		JOptionPane.showMessageDialog(null, outputArea, "World Population DataBase", JOptionPane.INFORMATION_MESSAGE);

	}

	/**
	 * Method to calculate percent total
	 */
	public static double percentTotal(double countryPopulation, double worldPopulation) {

		// Perform percent total calculation and store in variable
		double percentTotal = countryPopulation / worldPopulation * 100;

		// Keep to decimal place
		percentTotal = Double.parseDouble(twoDigits.format(percentTotal));

		// Return percent total calculation
		return percentTotal;

	}

	/**
	 * Method to sort countries in alphabetical order
	 */
	public static void alphaOrder(String countryName[], double countryPopulation[], double worldPopulationVariable, double percentTotal[], String countryFlags[]) {

		// sort the arrays by alphabetical order
		// loop through the whole array
		for (int i = 0 ; i < countryName.length ; i++)
		{
			//loop through to compare two elements next to each other
			for (int j = 0 ; j < countryName.length - 1 ; j++)
			{
				//compare one element to the next
				if (countryName[j].compareTo(countryName[j+1]) > 0)
				{
					// swap country names if not in increasing order
					String tempNames = countryName [j];
					countryName [j] = countryName [j + 1];
					countryName [j + 1] = tempNames;

					// swap populations to keep lists correct
					double tempPopulation = countryPopulation [j];
					countryPopulation [j] = countryPopulation [j + 1];
					countryPopulation [j + 1] = tempPopulation;

					// swap percent total to keep lists correct
					double tempPercent = percentTotal [j];
					percentTotal [j] = percentTotal [j+1];
					percentTotal [j+1] = tempPercent;

					// swap country flags to keep lists correct
					String tempFlags = countryFlags [j];
					countryFlags [j] = countryFlags [j+1];
					countryFlags [j+1] = tempFlags;

				} 
			}	// end for j
		}		// end for i

		// Call display method to display new sorted information
		WorldPopulationStudy.display(countryName, countryPopulation, worldPopulationVariable, percentTotal);
	}

	/**
	 * Method to sort from smallest to largest percent total
	 */
	public static void lowToHigh(String countryName[], double countryPopulation[], double worldPopulationVariable, double percentTotal[], String countryFlags[]) {

		// sort the arrays by increasing percent total
		// loop through the whole array
		for (int i = 0 ; i < percentTotal.length ; i++)
		{
			//loop through to compare two elements next to each other
			for (int j = 0 ; j < percentTotal.length - 1 ; j++)
			{
				//compare one element to the next
				if (percentTotal [j] > percentTotal [j + 1])
				{
					// swap percent total if not in increasing order
					double tempPercent = percentTotal [j];
					percentTotal [j] = percentTotal [j + 1];
					percentTotal [j + 1] = tempPercent;

					// swap country names to keep lists correct
					String tempNames = countryName [j];
					countryName [j] =  countryName [j + 1];
					countryName [j + 1] =  tempNames;

					// swap country populations to keep lists correct
					Double tempPopulation = countryPopulation [j];
					countryPopulation [j] = countryPopulation [j+1];
					countryPopulation [j+1] = tempPopulation;

					// swap country flags to keep lists correct
					String tempFlags = countryFlags [j];
					countryFlags [j] = countryFlags [j+1];
					countryFlags [j+1] = tempFlags;

				} 
			}	// end for j
		}		// end for i

		// Call display method to display new sorted information
		WorldPopulationStudy.display(countryName, countryPopulation, worldPopulationVariable, percentTotal);
	}

	/**
	 * Method to save files
	 */
	public static void saveFiles(String countryName[], double countryPopulation[], double worldPopulationVariable, double percentTotal[]) throws IOException {

		// Ask the user for the name of the file to save the information
		String nameOfFile = (String) JOptionPane.showInputDialog(null, "Enter the Name of File to Save to:", "FILE NAME", JOptionPane.INFORMATION_MESSAGE, save, null, "Name of File:");

		// Write to a new file formatted differently 
		FileWriter fileW = new FileWriter(nameOfFile);	// Open the file to write to 
		PrintWriter output = new PrintWriter(fileW);	

		// Loop through the array and write to the file
		for (int i = 0; i < countryName.length; i++) {
			// Write all information to new file
			output.println("Country: " + countryName[i] + " Population: " + (int)countryPopulation[i] + " % Total: " + percentTotal[i]);	
		}

		// Add the average to the file 
		output.println("\nWorld Population: \t" + oneDigit.format(worldPopulationVariable));

		fileW.close(); // Close the file writer

		// Display friendly message to user
		JOptionPane.showMessageDialog(null, "File Saved Successfully!", "SAVED", JOptionPane.INFORMATION_MESSAGE, save);
	}


	/**
	 * Method to search for country
	 */
	public static int findCountry(String countries[], String searchKey) {

		// Go through the array and look for the key
		for (int i = 0; i < countries.length; i++) {

			// Check if the name at i is the key
			if (countries[i].equalsIgnoreCase(searchKey)) {
				// Return the location or index
				return i;
			}
		}	// End of for loop

		return -1;	// searchKey not found
	}

}

