import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Arrays;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * 
 */

/**
 * @author Amit Singh Memhi
 * Date: June 17th, 2022
 * Description: 
 *
 */
public class WorldPopulationStudyGUI extends JFrame implements ActionListener{

	JButton next, previous, worldPic, save, quit, search, sort;
	ImageIcon earth;
	int nextCounter = 1;

	// Initialize variable for tab size 
	static int tabSize = 0;

	// To format number to no decimal place
	static DecimalFormat oneDigit = new DecimalFormat("#0");

	// Declare the arrays for country name, population and percentage from total
	static String countryName[], countryFlags[];
	static double countryPopulation[],  worldPopulation[], percentTotal[];

	static String countriesDisplayed[], flagsDisplayed[];
	static double populationDisplayed[], percentDisplayed[];

	static double worldPopulationVariable; 
	static String listDisplay;

	// Create text field to search for runner names
	static JTextField countrySearch = new JTextField();

	static // Create a Text Output Area
	JTextArea outputArea = new JTextArea();

	JComboBox<String> sortingOptionsMenu = new JComboBox<>();

	// Adding audio learned from: https://www.youtube.com/watch?v=SyZQVJiARTQ
	File file = new File("aroundTheWorld.wav");
	AudioInputStream audioStream = AudioSystem.getAudioInputStream(file);
	Clip clip = AudioSystem.getClip();
	
	File file2 = new File("click.wav");
	AudioInputStream audioStream2 = AudioSystem.getAudioInputStream(file2);
	Clip clip2 = AudioSystem.getClip();


	/**
	 * Window Constructor
	 */
	public WorldPopulationStudyGUI() throws IOException, UnsupportedAudioFileException, LineUnavailableException {
		// Window title
		super("World Population DataBase");

		// Setting size, location and unresizeable 
		pack();		// Frames content is at preferable size
		setSize(1200,700);
		setLocationRelativeTo(null);
		setLayout(null);
		getContentPane().setBackground(Color.DARK_GRAY);
		setResizable(false);
		
		// Open audio file
		clip.open(audioStream);
		clip.start();
		clip2.open(audioStream2);

		// Next button
		next = new JButton(">");
		next.setBounds(220,375,127,35);
		next.setFont(new Font("Serif", Font.BOLD, 25));
		next.addActionListener(this);
		next.setBackground(new Color(20,120,47));
		next.setForeground(Color.WHITE);

		// Save button
		save = new JButton("Save");
		save.setBounds(625, 500, 150, 35);
		save.setFont(new Font("Serif", Font.BOLD, 20));
		save.addActionListener(this);
		save.setForeground(new Color(0,36,255));

		// Quit button
		quit = new JButton("Quit");
		quit.setBounds(450, 500, 150, 35);
		quit.setFont(new Font("Serif", Font.BOLD, 20));
		quit.addActionListener(this);
		quit.setForeground(new Color(0,36,255));

		// Sort button
		sort = new JButton("Sort");
		sort.setBounds(800, 500, 150, 35);
		sort.setFont(new Font("Serif", Font.BOLD, 20));
		sort.addActionListener(this);
		sort.setForeground(new Color(0,36,255));

		// Search button
		search = new JButton();
		search.setBounds(50, 500, 35, 33);
		search.setFont(new Font("Serif", Font.BOLD, 20));
		search.addActionListener(this);
		search.setIcon(new ImageIcon("search.png"));

		// Create a drop-down menu
		String[] sortingOptions = {"Alpha Order", "Highest", "Lowest"};
		sortingOptionsMenu = new JComboBox<>(sortingOptions);
		sortingOptionsMenu.setBounds(975,500,175,35);
		sortingOptionsMenu.setFont(new Font("Serif", Font.BOLD, 20));
		sortingOptionsMenu.setForeground(new Color(0,36,255));

		// Previous button
		previous = new JButton("<");
		previous.setBounds(50,375,127,35);
		previous.setFont(new Font("Serif", Font.BOLD, 25));
		previous.addActionListener(this);
		previous.setBackground(new Color(20,120,47));
		previous.setForeground(Color.WHITE);

		// Country search text field
		countrySearch.setBounds(100,500,250,35);
		countrySearch.setBackground(Color.LIGHT_GRAY);
		countrySearch.setFont(new Font("Serif", Font.BOLD, 16));
		countrySearch.setText("Search for Country in POV");

		// Earth picture
		earth = new ImageIcon("One.PNG");
		worldPic = new JButton();
		worldPic.setDisabledIcon(earth);
		worldPic.setEnabled(false);
		worldPic.setIcon(earth);
		worldPic.setBounds(50,50,300,280);

		// Sets JTextArea font and color.
		Font font = new Font("Serif", Font.BOLD, 22);
		outputArea.setFont(font);
		outputArea.setBackground(Color.GRAY);
		outputArea.setForeground(Color.WHITE);
		outputArea.setEditable(false);	// Disable deleting 
		outputArea.setBounds(450,25,700,450);

		countriesDisplayed = new String[11];
		populationDisplayed = new double[11];
		percentDisplayed = new double[11];
		flagsDisplayed = new String[11];

		for (int i = 0; i < 11; i++) {

			countriesDisplayed[i] = countryName[i];
			populationDisplayed[i] = countryPopulation[i];
			percentDisplayed[i] = percentTotal[i];
			flagsDisplayed[i] = countryFlags[i];

		}

		listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
		outputArea.setText(listDisplay);
		// Set the tab size to the greatest length + 1
		outputArea.setTabSize(tabSize + 1);


		// Adding elements
		add(worldPic);
		add(worldPic);
		add(previous);
		add(save);
		add(quit);
		add(search);
		add(sort);
		add(sortingOptionsMenu);
		add(next);
		add(countrySearch);
		add(outputArea);

		// Setting exit on close and visibility  
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws IOException, UnsupportedAudioFileException, LineUnavailableException{

		// Open the data file for reading picture data
		FileReader fileR = new FileReader("Worldpopulation.txt");	// Find the file
		BufferedReader input = new BufferedReader(fileR);

		// Store the number of countries
		int numOfCountries = Integer.parseInt(input.readLine());

		// Create the arrays with the size of the flexible number
		countryName = new String[numOfCountries];
		countryFlags = new String[numOfCountries];
		countryPopulation = new double[numOfCountries];
		percentTotal = new double[numOfCountries];
		worldPopulation = new double[1];	// Set to 1 because there is only one number at the end

		// Use a for loop to load the data into the arrays
		for (int i = 0; i < numOfCountries; i++) {
			// Load the country names and their populations
			countryName[i] = input.readLine();
			countryPopulation[i] = Double.parseDouble(input.readLine());
		}

		// Store the world population in the first index of the array
		worldPopulation[0] = Double.parseDouble(input.readLine());
		worldPopulationVariable = worldPopulation[0];

		// Close the file
		fileR.close();

		// Open the data file for reading picture data
		FileReader fileR2 = new FileReader("CountryFlags.txt");	// Find the file
		BufferedReader input2 = new BufferedReader(fileR2);

		// Use a for loop to load the picture data into the arrays
		for (int i = 0; i < numOfCountries; i++) {
			// Load the country flags
			countryFlags[i] = input2.readLine();
		}

		fileR2.close(); // Close the file

		// Call percentTotal method to obtain %total of specific country
		for (int i = 0; i < numOfCountries; i++) {
			percentTotal[i] = WorldPopulationStudy.percentTotal(countryPopulation[i], worldPopulationVariable);
		}

		// Call window constructor
		new WorldPopulationStudyGUI();
	}

	/**
	 * Method to display information
	 */
	public static String display(String countryName[], double countryPopulation[], double worldPopulation, double percentTotal[]) {


		// Find the greatest length
		for (int i = 0; i < countryName.length; i++) {
			if (countryName[i].length() > tabSize) {
				tabSize = countryName[i].length();
			}
		}

		// Display the whole thing in a nice dialog box 
		String list = "Country\tPopulation\t% of Total\n";
		list = list + "======\t======\t======";

		// Add the country names, populations and percent totals to the list
		for (int i = 0; i < countryName.length; i++) {
			list = list + "\n" + countryName[i] + "\t" + (int)countryPopulation[i] + "\t" + percentTotal[i] + "%";
		}

		// Add the world population at the end of the list
		list = list + "\n\nTotal World Population: \t" + oneDigit.format(worldPopulation);

		return list;

	}

	/**
	 * Method to sort countries in alphabetical order
	 */
	public static void alphaOrder(String countryName[], double countryPopulation[], double worldPopulationVariable, double percentTotal[], String countryFlags[]) {

		// sort the arrays by alphabetical order
		// loop through the whole array
		for (int i = 0 ; i < countryName.length ; i++)
		{
			//loop through to compare two elements next to each other
			for (int j = 0 ; j < countryName.length - 1 ; j++)
			{
				//compare one element to the next
				if (countryName[j].compareTo(countryName[j+1]) > 0)
				{
					// swap country names if not in increasing order
					String tempNames = countryName [j];
					countryName [j] = countryName [j + 1];
					countryName [j + 1] = tempNames;

					// swap populations to keep lists correct
					double tempPopulation = countryPopulation [j];
					countryPopulation [j] = countryPopulation [j + 1];
					countryPopulation [j + 1] = tempPopulation;

					// swap percent total to keep lists correct
					double tempPercent = percentTotal [j];
					percentTotal [j] = percentTotal [j+1];
					percentTotal [j+1] = tempPercent;

					// swap country flags to keep lists correct
					String tempFlags = countryFlags [j];
					countryFlags [j] = countryFlags [j+1];
					countryFlags [j+1] = tempFlags;

				} 
			}	// end for j
		}		// end for i

		listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
		outputArea.setText(listDisplay);

	}

	/**
	 * Method to sort from smallest to largest percent total
	 */
	public static void lowToHigh(String countryName[], double countryPopulation[], double worldPopulationVariable, double percentTotal[], String countryFlags[]) {

		// sort the arrays by increasing percent total
		// loop through the whole array
		for (int i = 0 ; i < percentTotal.length ; i++)
		{
			//loop through to compare two elements next to each other
			for (int j = 0 ; j < percentTotal.length - 1 ; j++)
			{
				//compare one element to the next
				if (percentTotal [j] > percentTotal [j + 1])
				{
					// swap percent total if not in increasing order
					double tempPercent = percentTotal [j];
					percentTotal [j] = percentTotal [j + 1];
					percentTotal [j + 1] = tempPercent;

					// swap country names to keep lists correct
					String tempNames = countryName [j];
					countryName [j] =  countryName [j + 1];
					countryName [j + 1] =  tempNames;

					// swap country populations to keep lists correct
					Double tempPopulation = countryPopulation [j];
					countryPopulation [j] = countryPopulation [j+1];
					countryPopulation [j+1] = tempPopulation;

					// swap country flags to keep lists correct
					String tempFlags = countryFlags [j];
					countryFlags [j] = countryFlags [j+1];
					countryFlags [j+1] = tempFlags;

				} 
			}	// end for j
		}		// end for i

		listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
		outputArea.setText(listDisplay);
	}

	/**
	 * Method to sort from smallest to largest percent total
	 */
	public static void highToLow(String countryName[], double countryPopulation[], double worldPopulationVariable, double percentTotal[], String countryFlags[]) {

		// sort the arrays by increasing percent total
		// loop through the whole array
		for (int i = 0 ; i < percentTotal.length ; i++)
		{
			//loop through to compare two elements next to each other
			for (int j = 0 ; j < percentTotal.length - 1 ; j++)
			{
				//compare one element to the next
				if (percentTotal [j] < percentTotal [j + 1])
				{
					// swap percent total if not in increasing order
					double tempPercent = percentTotal [j];
					percentTotal [j] = percentTotal [j + 1];
					percentTotal [j + 1] = tempPercent;

					// swap country names to keep lists correct
					String tempNames = countryName [j];
					countryName [j] =  countryName [j + 1];
					countryName [j + 1] =  tempNames;

					// swap country populations to keep lists correct
					Double tempPopulation = countryPopulation [j];
					countryPopulation [j] = countryPopulation [j+1];
					countryPopulation [j+1] = tempPopulation;

					// swap country flags to keep lists correct
					String tempFlags = countryFlags [j];
					countryFlags [j] = countryFlags [j+1];
					countryFlags [j+1] = tempFlags;

				} 
			}	// end for j
		}		// end for i

		listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
		outputArea.setText(listDisplay);
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == quit) {
			clip2.setMicrosecondPosition(200000); // Restart clip
			clip2.start(); // Start clip 
			this.dispose();
		}

		else if (e.getSource() == save) {
			
			clip2.setMicrosecondPosition(200000); // Restart clip
			clip2.start(); // Start clip 
			try {
				WorldPopulationStudy.saveFiles(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
			} catch (IOException e1) {
			}
		}

		else if (e.getSource() == search) {
			
			clip2.setMicrosecondPosition(200000); // Restart clip
			clip2.start(); // Start clip 
			
			String countryToFind = countrySearch.getText();

			// Call the search method
			int location = WorldPopulationStudy.findCountry(countriesDisplayed, countryToFind);

			// Check if the name was found
			if(location >= 0) {

				// Initialize countryFlag to searched country's flag 
				ImageIcon countryFlag = new ImageIcon(flagsDisplayed[location]);

				// Display found
				JOptionPane.showMessageDialog(null,"Country: " + countriesDisplayed[location] + "\n" + "Population: " + (int)populationDisplayed[location] + "\nPercent Total: " + percentDisplayed[location] + "%", "COUNTRY FOUND!", JOptionPane.INFORMATION_MESSAGE, countryFlag);

				// Ask if user wants to refactor country information
				int changeOption = JOptionPane.showConfirmDialog(null,"Refactor Country Data?", "REFACTOR", JOptionPane.YES_NO_OPTION);

				// If user wants to change the information
				if (changeOption == JOptionPane.YES_OPTION) {

					// Set new population to same location 
					populationDisplayed[location] = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter New Country Population For " + countriesDisplayed[location] + ":"));

					// Call percent total method to calculate new percent total
					percentDisplayed[location] = WorldPopulationStudy.percentTotal(populationDisplayed[location], worldPopulationVariable);


					// Ask if user wants to save new data
					int saveOption = JOptionPane.showConfirmDialog(null,"Save New Information?", "SAVE", JOptionPane.YES_NO_OPTION);

					if (saveOption == JOptionPane.YES_OPTION) {

						try {
							WorldPopulationStudy.saveFiles(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);

							listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
							outputArea.setText(listDisplay);

						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}

					}
					else {
						// Otherwise display a friendly message
						JOptionPane.showMessageDialog(null, "Have A Nice Day!", "THANK YOU!", JOptionPane.INFORMATION_MESSAGE);
					}
				}
				else {
					// Otherwise display a friendly message
					JOptionPane.showMessageDialog(null, "Have A Nice Day!", "THANK YOU!", JOptionPane.INFORMATION_MESSAGE);
				}
			}
			else {
				// Display not found
				JOptionPane.showMessageDialog(null, "No Information Found For: " + countryToFind, "COUNTRY NOT FOUND!", JOptionPane.INFORMATION_MESSAGE);
			}
		}

		else if (e.getSource() == sort) {
			
			clip2.setMicrosecondPosition(200000); // Restart clip
			clip2.start(); // Start clip 
			
			String sortOption = (String) sortingOptionsMenu.getSelectedItem();

			if (sortOption.equals("Alpha Order")) {
				WorldPopulationStudyGUI.alphaOrder(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed, countryFlags);
			}

			else if (sortOption.equals("Lowest")) {
				WorldPopulationStudyGUI.lowToHigh(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed, countryFlags);
			}

			else {
				WorldPopulationStudyGUI.highToLow(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed, countryFlags);
			}
		}

		else if (e.getSource() == next) {
			
			clip2.setMicrosecondPosition(200000); // Restart clip
			clip2.start(); // Start clip 

			// Add one to counter
			nextCounter++;

			// Check which position
			if (nextCounter == 2) {
				earth = new ImageIcon("Two.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[4];
				countriesDisplayed[0] = countryName[2];
				countriesDisplayed[1] = countryName[5];
				countriesDisplayed[2] = countryName[9];
				countriesDisplayed[3] = countryName[10];

				populationDisplayed = new double[4];
				populationDisplayed[0] = countryPopulation[2];
				populationDisplayed[1] = countryPopulation[5];
				populationDisplayed[2] = countryPopulation[9];
				populationDisplayed[3] = countryPopulation[10];

				percentDisplayed = new double[4];
				percentDisplayed[0] = percentTotal[2];
				percentDisplayed[1] = percentTotal[5];
				percentDisplayed[2] = percentTotal[9];
				percentDisplayed[3] = percentTotal[10];

				flagsDisplayed = new String[4];
				flagsDisplayed[0] = countryFlags[2];
				flagsDisplayed[1] = countryFlags[5];
				flagsDisplayed[2] = countryFlags[9];
				flagsDisplayed[3] = countryFlags[10];


				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);


			}
			else if (nextCounter == 3) {
				earth = new ImageIcon("Three.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[5];
				countriesDisplayed[0] = countryName[2];
				countriesDisplayed[1] = countryName[5];
				countriesDisplayed[2] = countryName[9];
				countriesDisplayed[3] = countryName[10];
				countriesDisplayed[4] = countryName[6];

				populationDisplayed = new double[5];
				populationDisplayed[0] = countryPopulation[2];
				populationDisplayed[1] = countryPopulation[5];
				populationDisplayed[2] = countryPopulation[9];
				populationDisplayed[3] = countryPopulation[10];
				populationDisplayed[4] = countryPopulation[6];

				percentDisplayed = new double[5];
				percentDisplayed[0] = percentTotal[2];
				percentDisplayed[1] = percentTotal[5];
				percentDisplayed[2] = percentTotal[9];
				percentDisplayed[3] = percentTotal[10];
				percentDisplayed[4] = percentTotal[6];

				flagsDisplayed = new String[5];
				flagsDisplayed[0] = countryFlags[2];
				flagsDisplayed[1] = countryFlags[5];
				flagsDisplayed[2] = countryFlags[9];
				flagsDisplayed[3] = countryFlags[10];
				flagsDisplayed[4] = countryFlags[6];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);


			}
			else if (nextCounter == 4) {
				earth = new ImageIcon("Four.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[2];
				countriesDisplayed[0] = countryName[5];
				countriesDisplayed[1] = countryName[6];

				populationDisplayed = new double[2];
				populationDisplayed[0] = countryPopulation[5];
				populationDisplayed[1] = countryPopulation[6];

				percentDisplayed = new double[2];
				percentDisplayed[0] = percentTotal[5];
				percentDisplayed[1] = percentTotal[6];

				flagsDisplayed = new String[2];
				flagsDisplayed[0] = countryFlags[5];
				flagsDisplayed[1] = countryFlags[6];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);
			}
			else if (nextCounter == 5) {
				earth = new ImageIcon("Five.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[3];
				countriesDisplayed[0] = countryName[6];
				countriesDisplayed[1] = countryName[8];
				countriesDisplayed[2] = countryName[4];

				populationDisplayed = new double[3];
				populationDisplayed[0] = countryPopulation[6];
				populationDisplayed[1] = countryPopulation[8];
				populationDisplayed[2] = countryPopulation[4];

				percentDisplayed = new double[3];
				percentDisplayed[0] = percentTotal[6];
				percentDisplayed[1] = percentTotal[8];
				percentDisplayed[2] = percentTotal[4];

				flagsDisplayed = new String[3];
				flagsDisplayed[0] = countryFlags[6];
				flagsDisplayed[1] = countryFlags[8];
				flagsDisplayed[2] = countryFlags[4];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);
			}
			else if (nextCounter == 6) {
				earth = new ImageIcon("Six.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[6];
				countriesDisplayed[0] = countryName[6];
				countriesDisplayed[1] = countryName[0];
				countriesDisplayed[2] = countryName[1];
				countriesDisplayed[3] = countryName[4];
				countriesDisplayed[4] = countryName[8];
				countriesDisplayed[5] = countryName[7];

				populationDisplayed = new double[6];
				populationDisplayed[0] = countryPopulation[6];
				populationDisplayed[1] = countryPopulation[0];
				populationDisplayed[2] = countryPopulation[1];
				populationDisplayed[3] = countryPopulation[4];
				populationDisplayed[4] = countryPopulation[8];
				populationDisplayed[5] = countryPopulation[7];

				percentDisplayed = new double[6];
				percentDisplayed[0] = percentTotal[6];
				percentDisplayed[1] = percentTotal[0];
				percentDisplayed[2] = percentTotal[1];
				percentDisplayed[3] = percentTotal[4];
				percentDisplayed[4] = percentTotal[8];
				percentDisplayed[5] = percentTotal[7];

				flagsDisplayed = new String[6];
				flagsDisplayed[0] = countryFlags[6];
				flagsDisplayed[1] = countryFlags[0];
				flagsDisplayed[2] = countryFlags[1];
				flagsDisplayed[3] = countryFlags[4];
				flagsDisplayed[4] = countryFlags[8];
				flagsDisplayed[5] = countryFlags[7];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);
			}
			else if (nextCounter == 7) {
				earth = new ImageIcon("Seven.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[7];
				countriesDisplayed[0] = countryName[6];
				countriesDisplayed[1] = countryName[0];
				countriesDisplayed[2] = countryName[1];
				countriesDisplayed[3] = countryName[4];
				countriesDisplayed[4] = countryName[8];
				countriesDisplayed[5] = countryName[7];
				countriesDisplayed[6] = countryName[3];

				populationDisplayed = new double[7];
				populationDisplayed[0] = countryPopulation[6];
				populationDisplayed[1] = countryPopulation[0];
				populationDisplayed[2] = countryPopulation[1];
				populationDisplayed[3] = countryPopulation[4];
				populationDisplayed[4] = countryPopulation[8];
				populationDisplayed[5] = countryPopulation[7];
				populationDisplayed[6] = countryPopulation[3];

				percentDisplayed = new double[7];
				percentDisplayed[0] = percentTotal[6];
				percentDisplayed[1] = percentTotal[0];
				percentDisplayed[2] = percentTotal[1];
				percentDisplayed[3] = percentTotal[4];
				percentDisplayed[4] = percentTotal[8];
				percentDisplayed[5] = percentTotal[7];
				percentDisplayed[6] = percentTotal[3];

				flagsDisplayed = new String[7];
				flagsDisplayed[0] = countryFlags[6];
				flagsDisplayed[1] = countryFlags[0];
				flagsDisplayed[2] = countryFlags[1];
				flagsDisplayed[3] = countryFlags[4];
				flagsDisplayed[4] = countryFlags[8];
				flagsDisplayed[5] = countryFlags[7];
				flagsDisplayed[5] = countryFlags[3];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);
			}
			else if (nextCounter == 8) {
				earth = new ImageIcon("Eight.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[6];
				countriesDisplayed[0] = countryName[0];
				countriesDisplayed[1] = countryName[1];
				countriesDisplayed[2] = countryName[4];
				countriesDisplayed[3] = countryName[8];
				countriesDisplayed[4] = countryName[7];
				countriesDisplayed[5] = countryName[3];

				populationDisplayed = new double[6];
				populationDisplayed[0] = countryPopulation[0];
				populationDisplayed[1] = countryPopulation[1];
				populationDisplayed[2] = countryPopulation[4];
				populationDisplayed[3] = countryPopulation[8];
				populationDisplayed[4] = countryPopulation[7];
				populationDisplayed[5] = countryPopulation[3];

				percentDisplayed = new double[6];
				percentDisplayed[0] = percentTotal[0];
				percentDisplayed[1] = percentTotal[1];
				percentDisplayed[2] = percentTotal[4];
				percentDisplayed[3] = percentTotal[8];
				percentDisplayed[4] = percentTotal[7];
				percentDisplayed[5] = percentTotal[3];

				flagsDisplayed = new String[6];
				flagsDisplayed[0] = countryFlags[0];
				flagsDisplayed[1] = countryFlags[1];
				flagsDisplayed[2] = countryFlags[4];
				flagsDisplayed[3] = countryFlags[8];
				flagsDisplayed[4] = countryFlags[7];
				flagsDisplayed[5] = countryFlags[3];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);
			}
			else if (nextCounter == 9) {
				earth = new ImageIcon("Nine.PNG");
				worldPic.setDisabledIcon(earth);

			}
			else if (nextCounter == 10) {
				earth = new ImageIcon("Ten.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[4];
				countriesDisplayed[0] = countryName[0];
				countriesDisplayed[1] = countryName[8];
				countriesDisplayed[2] = countryName[7];
				countriesDisplayed[3] = countryName[3];

				populationDisplayed = new double[4];
				populationDisplayed[0] = countryPopulation[0];
				populationDisplayed[1] = countryPopulation[8];
				populationDisplayed[2] = countryPopulation[7];
				populationDisplayed[3] = countryPopulation[3];

				percentDisplayed = new double[4];
				percentDisplayed[0] = percentTotal[0];
				percentDisplayed[1] = percentTotal[8];
				percentDisplayed[2] = percentTotal[7];
				percentDisplayed[3] = percentTotal[3];

				flagsDisplayed = new String[4];
				flagsDisplayed[0] = countryFlags[0];
				flagsDisplayed[1] = countryFlags[0];
				flagsDisplayed[2] = countryFlags[7];
				flagsDisplayed[3] = countryFlags[3];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);
			}
			else if (nextCounter == 11) {
				earth = new ImageIcon("Eleven.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[3];
				countriesDisplayed[0] = countryName[10];
				countriesDisplayed[1] = countryName[8];
				countriesDisplayed[2] = countryName[2];

				populationDisplayed = new double[3];
				populationDisplayed[0] = countryPopulation[10];
				populationDisplayed[1] = countryPopulation[8];
				populationDisplayed[2] = countryPopulation[2];

				percentDisplayed = new double[3];
				percentDisplayed[0] = percentTotal[10];
				percentDisplayed[1] = percentTotal[8];
				percentDisplayed[2] = percentTotal[2];

				flagsDisplayed = new String[3];
				flagsDisplayed[0] = countryFlags[10];
				flagsDisplayed[1] = countryFlags[8];
				flagsDisplayed[2] = countryFlags[2];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);

			}
			else if (nextCounter == 12) {
				earth = new ImageIcon("Twelve.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[2];
				countriesDisplayed[0] = countryName[10];
				countriesDisplayed[1] = countryName[2];

				populationDisplayed = new double[2];
				populationDisplayed[0] = countryPopulation[10];
				populationDisplayed[1] = countryPopulation[2];

				percentDisplayed = new double[2];
				percentDisplayed[0] = percentTotal[10];
				percentDisplayed[1] = percentTotal[2];

				flagsDisplayed = new String[2];
				flagsDisplayed[0] = countryFlags[10];
				flagsDisplayed[1] = countryFlags[2];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);
			}
			else {
				nextCounter = 1;
				earth = new ImageIcon("One.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[11];
				populationDisplayed = new double[11];
				percentDisplayed = new double[11];
				flagsDisplayed = new String[11];

				for (int i = 0; i < 11; i++) {

					countriesDisplayed[i] = countryName[i];
					populationDisplayed[i] = countryPopulation[i];
					percentDisplayed[i] = percentTotal[i];
					flagsDisplayed[i] = countryFlags[i];

				}

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);

			}

		}

		else if (e.getSource() == previous) {
			
			clip2.setMicrosecondPosition(200000); // Restart clip
			clip2.start(); // Start clip 

			// Take away one from counter
			nextCounter--;

			// Check which position
			if (nextCounter == 2) {
				earth = new ImageIcon("Two.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[4];
				countriesDisplayed[0] = countryName[2];
				countriesDisplayed[1] = countryName[5];
				countriesDisplayed[2] = countryName[9];
				countriesDisplayed[3] = countryName[10];

				populationDisplayed = new double[4];
				populationDisplayed[0] = countryPopulation[2];
				populationDisplayed[1] = countryPopulation[5];
				populationDisplayed[2] = countryPopulation[9];
				populationDisplayed[3] = countryPopulation[10];

				percentDisplayed = new double[4];
				percentDisplayed[0] = percentTotal[2];
				percentDisplayed[1] = percentTotal[5];
				percentDisplayed[2] = percentTotal[9];
				percentDisplayed[3] = percentTotal[10];

				flagsDisplayed = new String[4];
				flagsDisplayed[0] = countryFlags[2];
				flagsDisplayed[1] = countryFlags[5];
				flagsDisplayed[2] = countryFlags[9];
				flagsDisplayed[3] = countryFlags[10];


				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);


			}
			else if (nextCounter == 3) {
				earth = new ImageIcon("Three.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[5];
				countriesDisplayed[0] = countryName[2];
				countriesDisplayed[1] = countryName[5];
				countriesDisplayed[2] = countryName[9];
				countriesDisplayed[3] = countryName[10];
				countriesDisplayed[4] = countryName[6];

				populationDisplayed = new double[5];
				populationDisplayed[0] = countryPopulation[2];
				populationDisplayed[1] = countryPopulation[5];
				populationDisplayed[2] = countryPopulation[9];
				populationDisplayed[3] = countryPopulation[10];
				populationDisplayed[4] = countryPopulation[6];

				percentDisplayed = new double[5];
				percentDisplayed[0] = percentTotal[2];
				percentDisplayed[1] = percentTotal[5];
				percentDisplayed[2] = percentTotal[9];
				percentDisplayed[3] = percentTotal[10];
				percentDisplayed[4] = percentTotal[6];

				flagsDisplayed = new String[5];
				flagsDisplayed[0] = countryFlags[2];
				flagsDisplayed[1] = countryFlags[5];
				flagsDisplayed[2] = countryFlags[9];
				flagsDisplayed[3] = countryFlags[10];
				flagsDisplayed[4] = countryFlags[6];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);


			}
			else if (nextCounter == 4) {
				earth = new ImageIcon("Four.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[2];
				countriesDisplayed[0] = countryName[5];
				countriesDisplayed[1] = countryName[6];

				populationDisplayed = new double[2];
				populationDisplayed[0] = countryPopulation[5];
				populationDisplayed[1] = countryPopulation[6];

				percentDisplayed = new double[2];
				percentDisplayed[0] = percentTotal[5];
				percentDisplayed[1] = percentTotal[6];

				flagsDisplayed = new String[2];
				flagsDisplayed[0] = countryFlags[5];
				flagsDisplayed[1] = countryFlags[6];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);
			}
			else if (nextCounter == 5) {
				earth = new ImageIcon("Five.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[3];
				countriesDisplayed[0] = countryName[6];
				countriesDisplayed[1] = countryName[8];
				countriesDisplayed[2] = countryName[4];

				populationDisplayed = new double[3];
				populationDisplayed[0] = countryPopulation[6];
				populationDisplayed[1] = countryPopulation[8];
				populationDisplayed[2] = countryPopulation[4];

				percentDisplayed = new double[3];
				percentDisplayed[0] = percentTotal[6];
				percentDisplayed[1] = percentTotal[8];
				percentDisplayed[2] = percentTotal[4];

				flagsDisplayed = new String[3];
				flagsDisplayed[0] = countryFlags[6];
				flagsDisplayed[1] = countryFlags[8];
				flagsDisplayed[2] = countryFlags[4];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);
			}
			else if (nextCounter == 6) {
				earth = new ImageIcon("Six.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[6];
				countriesDisplayed[0] = countryName[6];
				countriesDisplayed[1] = countryName[0];
				countriesDisplayed[2] = countryName[1];
				countriesDisplayed[3] = countryName[4];
				countriesDisplayed[4] = countryName[8];
				countriesDisplayed[5] = countryName[7];

				populationDisplayed = new double[6];
				populationDisplayed[0] = countryPopulation[6];
				populationDisplayed[1] = countryPopulation[0];
				populationDisplayed[2] = countryPopulation[1];
				populationDisplayed[3] = countryPopulation[4];
				populationDisplayed[4] = countryPopulation[8];
				populationDisplayed[5] = countryPopulation[7];

				percentDisplayed = new double[6];
				percentDisplayed[0] = percentTotal[6];
				percentDisplayed[1] = percentTotal[0];
				percentDisplayed[2] = percentTotal[1];
				percentDisplayed[3] = percentTotal[4];
				percentDisplayed[4] = percentTotal[8];
				percentDisplayed[5] = percentTotal[7];

				flagsDisplayed = new String[6];
				flagsDisplayed[0] = countryFlags[6];
				flagsDisplayed[1] = countryFlags[0];
				flagsDisplayed[2] = countryFlags[1];
				flagsDisplayed[3] = countryFlags[4];
				flagsDisplayed[4] = countryFlags[8];
				flagsDisplayed[5] = countryFlags[7];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);
			}
			else if (nextCounter == 7) {
				earth = new ImageIcon("Seven.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[7];
				countriesDisplayed[0] = countryName[6];
				countriesDisplayed[1] = countryName[0];
				countriesDisplayed[2] = countryName[1];
				countriesDisplayed[3] = countryName[4];
				countriesDisplayed[4] = countryName[8];
				countriesDisplayed[5] = countryName[7];
				countriesDisplayed[6] = countryName[3];

				populationDisplayed = new double[7];
				populationDisplayed[0] = countryPopulation[6];
				populationDisplayed[1] = countryPopulation[0];
				populationDisplayed[2] = countryPopulation[1];
				populationDisplayed[3] = countryPopulation[4];
				populationDisplayed[4] = countryPopulation[8];
				populationDisplayed[5] = countryPopulation[7];
				populationDisplayed[6] = countryPopulation[3];

				percentDisplayed = new double[7];
				percentDisplayed[0] = percentTotal[6];
				percentDisplayed[1] = percentTotal[0];
				percentDisplayed[2] = percentTotal[1];
				percentDisplayed[3] = percentTotal[4];
				percentDisplayed[4] = percentTotal[8];
				percentDisplayed[5] = percentTotal[7];
				percentDisplayed[6] = percentTotal[3];

				flagsDisplayed = new String[7];
				flagsDisplayed[0] = countryFlags[6];
				flagsDisplayed[1] = countryFlags[0];
				flagsDisplayed[2] = countryFlags[1];
				flagsDisplayed[3] = countryFlags[4];
				flagsDisplayed[4] = countryFlags[8];
				flagsDisplayed[5] = countryFlags[7];
				flagsDisplayed[5] = countryFlags[3];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);
			}
			else if (nextCounter == 8) {
				earth = new ImageIcon("Eight.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[6];
				countriesDisplayed[0] = countryName[0];
				countriesDisplayed[1] = countryName[1];
				countriesDisplayed[2] = countryName[4];
				countriesDisplayed[3] = countryName[8];
				countriesDisplayed[4] = countryName[7];
				countriesDisplayed[5] = countryName[3];

				populationDisplayed = new double[6];
				populationDisplayed[0] = countryPopulation[0];
				populationDisplayed[1] = countryPopulation[1];
				populationDisplayed[2] = countryPopulation[4];
				populationDisplayed[3] = countryPopulation[8];
				populationDisplayed[4] = countryPopulation[7];
				populationDisplayed[5] = countryPopulation[3];

				percentDisplayed = new double[6];
				percentDisplayed[0] = percentTotal[0];
				percentDisplayed[1] = percentTotal[1];
				percentDisplayed[2] = percentTotal[4];
				percentDisplayed[3] = percentTotal[8];
				percentDisplayed[4] = percentTotal[7];
				percentDisplayed[5] = percentTotal[3];

				flagsDisplayed = new String[6];
				flagsDisplayed[0] = countryFlags[0];
				flagsDisplayed[1] = countryFlags[1];
				flagsDisplayed[2] = countryFlags[4];
				flagsDisplayed[3] = countryFlags[8];
				flagsDisplayed[4] = countryFlags[7];
				flagsDisplayed[5] = countryFlags[3];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);
			}
			else if (nextCounter == 9) {
				earth = new ImageIcon("Nine.PNG");
				worldPic.setDisabledIcon(earth);

			}
			else if (nextCounter == 10) {
				earth = new ImageIcon("Ten.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[4];
				countriesDisplayed[0] = countryName[0];
				countriesDisplayed[1] = countryName[8];
				countriesDisplayed[2] = countryName[7];
				countriesDisplayed[3] = countryName[3];

				populationDisplayed = new double[4];
				populationDisplayed[0] = countryPopulation[0];
				populationDisplayed[1] = countryPopulation[8];
				populationDisplayed[2] = countryPopulation[7];
				populationDisplayed[3] = countryPopulation[3];

				percentDisplayed = new double[4];
				percentDisplayed[0] = percentTotal[0];
				percentDisplayed[1] = percentTotal[8];
				percentDisplayed[2] = percentTotal[7];
				percentDisplayed[3] = percentTotal[3];

				flagsDisplayed = new String[4];
				flagsDisplayed[0] = countryFlags[0];
				flagsDisplayed[1] = countryFlags[0];
				flagsDisplayed[2] = countryFlags[7];
				flagsDisplayed[3] = countryFlags[3];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);
			}
			else if (nextCounter == 11) {
				earth = new ImageIcon("Eleven.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[3];
				countriesDisplayed[0] = countryName[10];
				countriesDisplayed[1] = countryName[8];
				countriesDisplayed[2] = countryName[2];

				populationDisplayed = new double[3];
				populationDisplayed[0] = countryPopulation[10];
				populationDisplayed[1] = countryPopulation[8];
				populationDisplayed[2] = countryPopulation[2];

				percentDisplayed = new double[3];
				percentDisplayed[0] = percentTotal[10];
				percentDisplayed[1] = percentTotal[8];
				percentDisplayed[2] = percentTotal[2];

				flagsDisplayed = new String[3];
				flagsDisplayed[0] = countryFlags[10];
				flagsDisplayed[1] = countryFlags[8];
				flagsDisplayed[2] = countryFlags[2];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);

			}
			else if (nextCounter == 12) {
				earth = new ImageIcon("Twelve.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[2];
				countriesDisplayed[0] = countryName[10];
				countriesDisplayed[1] = countryName[2];

				populationDisplayed = new double[2];
				populationDisplayed[0] = countryPopulation[10];
				populationDisplayed[1] = countryPopulation[2];

				percentDisplayed = new double[2];
				percentDisplayed[0] = percentTotal[10];
				percentDisplayed[1] = percentTotal[2];

				flagsDisplayed = new String[2];
				flagsDisplayed[0] = countryFlags[10];
				flagsDisplayed[1] = countryFlags[2];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);
			}
			else {
				nextCounter = 12;
				earth = new ImageIcon("Twelve.PNG");
				worldPic.setDisabledIcon(earth);

				countriesDisplayed = new String[2];
				countriesDisplayed[0] = countryName[10];
				countriesDisplayed[1] = countryName[2];

				populationDisplayed = new double[2];
				populationDisplayed[0] = countryPopulation[10];
				populationDisplayed[1] = countryPopulation[2];

				percentDisplayed = new double[2];
				percentDisplayed[0] = percentTotal[10];
				percentDisplayed[1] = percentTotal[2];

				flagsDisplayed = new String[2];
				flagsDisplayed[0] = countryFlags[10];
				flagsDisplayed[1] = countryFlags[2];

				listDisplay = display(countriesDisplayed, populationDisplayed, worldPopulationVariable, percentDisplayed);
				outputArea.setText(listDisplay);
				// Set the tab size to the greatest length + 1
				outputArea.setTabSize(tabSize + 1);

			}


		}



	}

}
